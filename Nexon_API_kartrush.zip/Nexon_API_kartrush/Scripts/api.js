// api.js

// OUID를 검색하는 함수
async function fetchOuid(racerName) {
    const ouidUrl = `https://open.api.nexon.com/kartrush/v1/id?racer_name=${encodeURIComponent(racerName)}`;
    try {
        const response = await fetch(ouidUrl, {
            method: 'GET',
            headers: {
                'x-nxopen-api-key': 'YOUR_API_KEY', // 실제 API 키를 입력해야 합니다.
            }
        });
        if (!response.ok) throw new Error('OUID not found or API request failed');
        const data = await response.json();
        if (data && data.ouid_info && data.ouid_info.length > 0) {
            return data.ouid_info[0].ouid;
        } else {
            throw new Error('OUID not found in the response');
        }
    } catch (error) {
        console.error('Error fetching OUID:', error);
        alert('OUID not found or there was an error with the request.');
        return null;
    }
}

// OUID를 사용하여 타이틀과 장비 정보를 검색하는 함수
async function fetchTitleAndEquipment(ouid) {
    const titleEquipmentUrl = `https://open.api.nexon.com/kartrush/v1/user/title-equipment?ouid=${ouid}`;
    try {
        const response = await fetch(titleEquipmentUrl, {
            method: 'GET',
            headers: {
                'x-nxopen-api-key': 'YOUR_API_KEY',
            }
        });
        if (!response.ok) throw new Error('Title and equipment not found or API request failed');
        const data = await response.json();
        return data; // 데이터 처리는 UI 관련 코드에서 수행
    } catch (error) {
        console.error('Error fetching title and equipment:', error);
        alert('Title and equipment not found or there was an error with the request.');
    }
}

export { fetchOuid, fetchTitleAndEquipment };
