// ui.js

import { fetchOuid, fetchTitleAndEquipment } from './api.js';

// 화면에 타이틀과 장비 정보를 표시하는 함수
function displayTitleAndEquipment(data) {
    const playerInfoSection = document.getElementById('player-info');
    playerInfoSection.innerHTML = ''; // Clear previous content
    if (data.title_equipment && data.title_equipment.length > 0) {
        const titleEquipmentHtml = data.title_equipment.map(item => `
            <p>Title: ${item.title || "No title"}</p>
            <p>Equipment: ${item.equipment || "No equipment"}</p>
        `).join('');
        playerInfoSection.innerHTML = titleEquipmentHtml;
    } else {
        playerInfoSection.innerHTML = '<p>This player does not have any titles or equipment.</p>';
    }
    playerInfoSection.classList.remove('hidden');
}

async function handleSearch() {
    const racerName = document.getElementById('search-player').value.trim();
    if (racerName) {
        const ouid = await fetchOuid(racerName);
        if (ouid) {
            const data = await fetchTitleAndEquipment(ouid);
            displayTitleAndEquipment(data);
        }
    } else {
        alert('Please enter a racer name.');
    }
}

function initSearch() {
    document.addEventListener('DOMContentLoaded', () => {
        const searchButton = document.getElementById('search-button');
        searchButton.addEventListener('click', handleSearch);
    });
}

export { initSearch };
